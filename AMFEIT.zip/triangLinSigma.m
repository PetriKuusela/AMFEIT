function int=triangLinSigma(g,s,ip,L);

% Lasketaan sigman arvot integrointipisteiss�
sigma = [1-ip(:,1)-ip(:,2),ip(:,1),ip(:,2)]*s;

Jt = L*g;
iJt = inv(Jt);
dJt = abs(det(Jt));
G = iJt*L;
GdJt = G'*G*dJt/6;
int = sum(sigma)*GdJt;
